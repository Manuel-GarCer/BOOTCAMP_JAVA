package com.customer.codigo.mscustomer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCustomerApplicationTests {

    @Test
    void contextLoads() {
    }

}
