package com.customer.codigo.mscustomer.service;

import com.customer.codigo.mscustomer.entity.Customer;
import com.customer.codigo.mscustomer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    CustomerRepository customerRepository;
    @Override
    public Mono<Customer> create(Customer customer) {
        return customerRepository.save(customer);
    }
    @Override
	public Mono<Customer> update(Customer customer) {
		return customerRepository.findById(customer.getId()).flatMap(custDB -> {
			return customerRepository.save(customer);
		});
	}

    @Override
	public Mono<Customer> findById(String id) {
		return customerRepository.findById(id);
	}

    @Override
	public Flux<Customer> findAll() {
		return customerRepository.findAll();
	}

    @Override
	public Mono<Boolean> delete(String id) {
		return customerRepository.findById(id)
				.flatMap(deleteCustomer -> customerRepository.delete(deleteCustomer).then(Mono.just(Boolean.TRUE)))
				.defaultIfEmpty(Boolean.FALSE);
	}

}
