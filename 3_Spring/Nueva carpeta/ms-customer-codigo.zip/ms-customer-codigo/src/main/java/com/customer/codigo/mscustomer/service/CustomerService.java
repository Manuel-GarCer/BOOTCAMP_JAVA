package com.customer.codigo.mscustomer.service;

import com.customer.codigo.mscustomer.entity.Customer;
import com.customer.codigo.mscustomer.entity.TypeCustomer;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomerService {
    public Mono<Customer> create(Customer customer);

    public Mono<Customer> update(Customer customer);

    public Mono<Customer> findById(String id);

    public Flux<Customer> findAll();

    public Mono<Boolean> delete(String id);

    //public Mono<TypeCustomer> findTypeCustomer(String id);
}
